/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tutorial2;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Tutorial2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Question 1
        //a
        System.out.print("Faculty of ");
        System.out.print("Computer Science ");
        System.out.print("and ");
        System.out.println("Information Technology");
        //b
        System.out.println("Faculty of \nComputer Science \nand \nInformation Technology");
        
        //Question 2
        System.out.println("SDN");
        
        //Question 3
        //a
        System.out.println("Java Programming");        
        //b
        System.out.println("Introduction to Java!");        
        //c
        System.out.println("\\t is the horizontal tab character");
        //d
        System.out.println("Java is case sensitive");
        
        //Question 4
        //a
        String matricNo;
        //b
        final double PI;    
        //c
        boolean M = false;
        //d
        long P = 8800000000L;
        //e
        char letter = 'U';
        //f
        final String PRO = "Java";
        
        //Question 5
        //a
        final double AMOUNT = 32.5;
        System.out.println("The Amount is " + AMOUNT);
        //b
        String chapter = "Summary";
        System.out.println(chapter);
        //c
        int num = 0;
        num++;
        int num1 = num;      
        //d
        float num = 3000;
        System.out.printf("%4.2f\n",num);
        //e
        String contact;
        Scanner keyboard = new Scanner(System.in);
        contact = keyboard.nextLine();
        
        //Question 6
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter diameter: ");
        double diameter = sc.nextDouble();
        double circumference = Math.PI * diameter;
        System.out.printf("The circumference of the circle is : %.3f\n ", circumference);
        
        //Question 7
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter value in inch : ");
        double inches = sc.nextDouble();
        double meters = (inches*2.54) /100;
        System.out.printf(inches + " inches = %.2f meters\n", meters);
    }
    
}
