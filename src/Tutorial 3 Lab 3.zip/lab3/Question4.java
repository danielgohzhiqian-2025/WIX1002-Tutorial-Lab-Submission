/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;

import java.util.Random;

/**
 *
 * @author User
 */
public class Question4 {
    public static void main(String[] args) {
        Random random = new Random();
        int player1 = 0;
        int player2 = 0;
        
        for(int i = 0; i < 2;i++){
            player1 = player1 + random.nextInt(6)+1;
            player2 = player2 + random.nextInt(6)+1;
        }
        
        System.out.println("Player 1: "+ player1);
        System.out.println("Player 2: "+ player2);
        
        if(player1>player2){
            System.out.println("Player 1 Win!");
        }else if(player2 > player1){
            System.out.println("Player 2 Win!");
        }else
            System.out.println("Draw");
    }
}
